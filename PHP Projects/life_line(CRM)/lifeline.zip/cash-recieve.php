<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Cash Recieve</title>
	<link rel="stylesheet" href="css\bootstrap.min.css">
	<link rel="stylesheet" href="css\custom-theme.css">
	<script src="js\bootstrap.min.js" type="text/javascript"></script>
</head>
<body>
	<div class="container-fluid">
		<div class="row ">
			<div class="col-lg-2"></div>
			<div class="col-lg-8 border border-success ">
				<div class="row">
					<div class="col-lg-9">
						<h1 class="text-center green"> تفصیل آمدن</h1>	
					</div>
					<div class="col-lg-3 text-left">
						<label>Balance:</label>
						<input class="mediumInputBox" type="text"  name="">
					</div>
				</div>
			</div>
			<div class="col-lg-2"></div>
		</div>
		<br>
		<div class="row border border-danger text-center">
			<div class="col-lg-12">
				<label>  تفصیل</label>
				<input type="text" name="">
				<label>  روپے</label>
				<input type="text" name="">
				<label> کھاتہ بنام</label>
				<input type="text" name="">
				<label>تاریخ</label>
				<input type="date" name="">
			</div>
			<br/>
			<br/>
			<br/>
			<div class="col-lg-12">
				<input type="button" name="" value="Add new entry">
				<input type="button" name="" value="Save entry">
				<input type="button" name="" value="Cancel">
				<input type="button" name="" value="Exit">
			</div>
			
		</div>
	</div>
</body>
</html>