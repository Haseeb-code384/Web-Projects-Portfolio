<div class="row">
	<div class="col-lg-12 text-danger ">
		<h1 class="text-center border header"><?php echo"$project_name"; ?></h1>
	</div>
</div>