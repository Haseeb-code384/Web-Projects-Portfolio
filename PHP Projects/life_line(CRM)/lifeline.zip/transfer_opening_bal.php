<?php
include("config.php");
include("allFunctions.php");


?>
	