<?php

session_start();

include '../config.php';

 echo $user_id = $_GET['view_id'];
  


?>